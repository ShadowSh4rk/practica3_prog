PDI.java
/**
 * 
 * Representa el personal docent i investigador.
 * 
 * 
 *  departament (DEIM, DEEEA, DEQ, ...)
 *   campus on treballa
 */

public class PDI extends Usuari {

    // departament

    // campus de treball


    // capçalera del constructor
    // public PDI(String alies, String correu, String departament, String campus);


    // mètodes específics per PDI si cal
}

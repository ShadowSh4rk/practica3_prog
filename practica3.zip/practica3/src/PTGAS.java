/**
 * 
 * Representa el personal tècnic i de gestió.
 * 
 *  - campus on treballa
 */

public class PTGAS extends Usuari {

    // campus de treball


    // capçalera del constructor
    // public PTGAS(String alies, String correu, String campus);

}

/**
 * 
 * Representa un estudiant matriculat a un ensenyament URV.
 * 
*ensenyament (GEI, GESST, BioGEI, ...) 
* any inici

 *  
 */

public class Estudiant extends Usuari {

    // ensenyament matriculat

    // any d'inici dels estudis


    // capçalera del constructor
    // public Estudiant(String alies, String correu, String ensenyament, int anyInici);

}

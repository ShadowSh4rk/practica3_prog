public class LlistaActivitats {

}

/**
 * Classe de gestió de la llista d'usuaris.
 * 
 *
 *  carregar usuaris des d'arxiu
 *  cercar usuaris per alies
 *  afegir nous usuaris
 */

public class LlistaUsuaris {

    // estructura on es guardaran tots els usuaris registrats

    // capçalera per afegir un usuari
    // public void afegirUsuari(Usuari u);

    // capçalera per buscar un usuari per alies
    // public Usuari buscar(String alies);

}

